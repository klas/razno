<?php
/**
 * @url				http://www.seblod.com
 * @editor			Octopoos - www.octopoos.com
 * @copyright		Copyright (C) 2013 SEBLOD. All Rights Reserved.
 * @license 			GNU General Public License version 2 or later; see _LICENSE.php
 **/


defined('_JEXEC') or die;

class PlgSystemVariableconvert extends JPlugin
{
	private $input;
	/**
	 * Constructor.
	 *
	 * @param   object  &$subject  The object to observe.
	 * @param   array   $config    An optional associative array of configuration settings.
	 *
	 * @since   1.5
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
		$this->input     = JFactory::getApplication()->input;
	}

	/**
	 * Converting the site URL to fit to the HTTP request.
	 *
	 * @return  void
	 *
	 * @since   1.5
	 */
	public function onAfterInitialise()
	{
		$var = $this->input->get('vd_type', array(), 'array');
		$var = '\'' . implode('\',\'' , $var) . '\'' ;
		$this->input->set('vd_type', $var);
	}


}
